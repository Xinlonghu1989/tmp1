# -*- coding: utf-8 -*-
"""Phase 0-2：日本語10件で「この計画のまま進めてよいか」を判定する。

これは規模の小さいテストだが、**検証全体で最も重要な分岐点**である。
Bedrock Guardrails のマネージドPIIは英語圏の書式に最適化されている可能性があり、
日本語の氏名・住所・マイナンバーが拾えるかは未検証のまま計画を組んでいる。

  分岐A（日本語PII 3/4以上を検出）
      → 当初計画どおり。Phase 1 で全190件を流す。
  分岐B（日本語PII 2/4以下）
      → 「Guardrailsが8割・自前が2割」という前提が崩れる。
        構図を「Guardrailsは有害表現・注入が主／PIIは自前検査が主」に組み替え、
        スライドと STAGE 1 の工数見積り（3〜4人日）を見直す。

使い方:
    export GUARDRAIL_ID=xxxxxxxx
    python3 probe_min.py
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import guard  # noqa: E402


def main() -> int:
    if not os.getenv("GUARDRAIL_ID"):
        print("GUARDRAIL_ID が未設定です。先に以下を実行してください。\n"
              "  python3 setup_guardrail.py check\n"
              "  python3 setup_guardrail.py create config/guardrail_02_strict.json",
              file=sys.stderr)
        return 2

    path = HERE / "data" / "min.jsonl"
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

    print(f"構成: {os.getenv('GUARDRAIL_ID')} / {os.getenv('GUARDRAIL_VERSION', 'DRAFT')} "
          f"/ {os.getenv('GUARDRAIL_REGION', 'ap-northeast-1')}\n")
    print(f"{'ID':<8}{'カテゴリ':<14}{'期待':<7}{'結果':<10}{'検出内容'}")
    print("─" * 96)

    results = []
    for record in records:
        source = "OUTPUT" if record["set"] == "D" else "INPUT"
        outcome = guard.check(record["text"], source=source)
        hit = outcome.intervened
        if not outcome.ok:
            mark, detail = "エラー", outcome.error[:50]
        elif record["expect"] == "PASS":
            mark = "○ 通過" if not hit else "× 誤検出"
            detail = ";".join(outcome.kinds) or "-"
        else:
            mark = "○ 検出" if hit else "× 見逃し"
            detail = ";".join(outcome.kinds) or "-"
        results.append((record, outcome, mark))
        print(f"{record['id']:<8}{record['category']:<14}{record['expect']:<7}{mark:<10}{detail}")

    # ── 判定 ──────────────────────────────────────────
    ja_pii = [(r, o) for r, o, _ in results if r["id"] in ("MIN-01", "MIN-02", "MIN-03", "MIN-04")]
    ja_hit = sum(1 for _, o in ja_pii if o.intervened)
    en_pii = next((o for r, o, _ in results if r["id"] == "MIN-05"), None)
    harm = [(r, o) for r, o, _ in results if r["set"] == "B"]
    harm_hit = sum(1 for _, o in harm if o.intervened)
    normal = [(r, o) for r, o, _ in results if r["set"] == "D"]
    fp = sum(1 for _, o in normal if o.intervened)

    print("\n" + "═" * 96)
    print("判定")
    print("═" * 96)
    print(f"  日本語PII の検出      : {ja_hit}/4")
    print(f"  英語圏PII の検出      : {'あり' if en_pii and en_pii.intervened else 'なし'}（対照群）")
    print(f"  有害・注入の検出      : {harm_hit}/3")
    print(f"  正常文の誤検出        : {fp}/2")

    if ja_hit >= 3:
        print("\n▶ 分岐A：日本語PIIが実用水準で検出できています。")
        print("  当初計画どおり Phase 1 へ進みます。")
        print("    python3 probe.py --label 構成2強化")
    else:
        print("\n▶ 分岐B：日本語PIIの検出が不足しています。")
        print("  「Guardrailsが8割・自前が2割」という前提が成立しません。")
        print("  次の順で計画を組み替えてください。")
        print("    1. 構成②のカスタム正規表現（config/guardrail_02_strict.json の regexesConfig）")
        print("       だけで、どこまで拾えるかを再測定する")
        print("    2. それでも不足なら、PII検査を自前実装（形態素解析＋辞書）に寄せ、")
        print("       Guardrails は有害表現・注入・拒否トピックに用途を限定する")
        print("    3. doc/ガードレール守備範囲と実装計画.html の 8:2 の比率と、")
        print("       STAGE 1 の工数（3〜4人日）を見直す")
    if en_pii and en_pii.intervened and ja_hit <= 1:
        print("\n  ※ 英語では検出でき日本語では検出できない場合、言語対応の問題が確定します。")
        print("     この事実は先方への報告材料として重要なので、CSVを残してください。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
