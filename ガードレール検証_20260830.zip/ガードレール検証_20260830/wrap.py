# -*- coding: utf-8 -*-
"""Phase 2：アプリの関数を実行時に差し替えて、実経路で検査する。

**アプリのファイルは1バイトも書き換えない。** import 済みモジュールの属性を
差し替えるだけで、差し替えはこのプロセスのメモリ上だけに存在する。

差し替えが効く根拠（検証計画 §C-1・実測済み）:
  - `from ai_client import chat` 形式の直接 import はリポジトリ内にゼロ件。
    全ての呼び出しが `ai_client.chat(...)` の属性参照である。
  - `call_chat` / `call_chat_json` は内部で bare name の `chat` / `chat_json` を
    呼ぶため、モジュール属性を差し替えると **これらにも波及する**。
    したがって差し替え点は chat と chat_json の2つで全経路を覆える。

検査の頻度（§B-1）:
  ApplyGuardrail は概ね1,000文字＝1テキスト単位の従量課金。プロンプトには
  最大30,000字の文脈が載る（app.py:608 等）。毎回プロンプト全体を通すと
  1回あたり30単位を課金・遅延することになるため、**毎回検査するのは
  「利用者の発話」と「最終出力」だけ**にする。RAG・添付・ウェブ本文は
  素材の取得時に1回だけ検査する設計（本番実装でもこの方針を踏襲する）。
"""

from __future__ import annotations

import os
import re
import sys
import threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for path in (str(HERE), str(ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

import guard  # noqa: E402

# 検査を通した記録。検証後に集計する。
STATS: dict[str, int] = {"input": 0, "output": 0, "question": 0,
                         "blocked": 0, "masked": 0, "error": 0, "text_units": 0}
_LOCK = threading.Lock()

BLOCKED_REPLY = "（入力または回答に問題が検出されたため、この内容は表示できません。）"

# ログ用の簡易マスク（§C-3）。
# applog が本文を書くのは knowledge_rag.py:2886 の query=search_text[:80] の1か所だけ。
# 全ログイベントを課金APIに通すのは過剰なので、ここはローカルの正規表現で足りる。
# 適用順が重要。緩いパターン（電話）を先に当てると、社員番号 HH-2026-00123 の
# "026-00123" の部分を電話として食ってしまう（自己テストで実際に検出した）。
# 具体的なものから先に置換し、電話には前後の境界を付ける。
LOG_PATTERNS = [
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "{EMAIL}"),
    (re.compile(r"(?i)(?:HH|ＨＨ)[-－]?[0-9０-９]{4}[-－]?[0-9０-９]{4,6}"), "{EMPLOYEE_ID}"),
    (re.compile(r"(?<![0-9０-９-－])(?:[0-9０-９][ -－]?){11}[0-9０-９](?![0-9０-９])"), "{MY_NUMBER}"),
    # 境界に \w を使うと、日本語文中（「連絡先は090-…」）で一切マッチしない。
    # Python の \w は日本語文字も語構成文字として扱うため。ASCII だけで境界を書く。
    (re.compile(r"(?<![0-9０-９A-Za-z\-－])0[0-9０-９]{1,4}[-－\s]?[0-9０-９]{1,4}[-－\s]?[0-9０-９]{3,4}(?![0-9０-９A-Za-z\-－])"), "{PHONE}"),
]


def mask_for_log(text: str) -> str:
    for pattern, holder in LOG_PATTERNS:
        text = pattern.sub(holder, text)
    return text


def _count(key: str, n: int = 1) -> None:
    with _LOCK:
        STATS[key] = STATS.get(key, 0) + n


def _screen(text: str, source: str) -> tuple[bool, str]:
    """検査して (通してよいか, 使うべきテキスト) を返す。

    API が落ちたときは通さない（fail-closed）。検査できないまま回答を出すと、
    ガードレールを入れた意味がなくなるため。
    """
    result = guard.check(text, source=source)
    _count("text_units", result.text_units)
    if not result.ok:
        _count("error")
        return False, ""
    if result.blocked:
        _count("blocked")
        return False, ""
    if result.detections:
        _count("masked")
    return True, result.text or text


def _user_text(messages: list[dict]) -> str:
    """毎回検査する対象＝利用者の発話だけを取り出す。

    system には RAG 検索結果・添付本文・ウェブ本文が最大30,000字入る。
    これを毎回通すと費用と遅延が破綻するため、ここでは対象にしない
    （素材は取得時に1回検査する方針。§B-1）。
    """
    parts = []
    for item in messages or []:
        if item.get("role") == "user":
            content = item.get("content", "")
            parts.append(content if isinstance(content, str) else str(content))
    return "\n".join(parts)


def install() -> None:
    """アプリのモジュールを import して、対象の関数を差し替える。"""
    import ai_client
    import response_store
    import applog

    # ── ① ai_client.chat（自由文の回答） ───────────────────
    original_chat = ai_client.chat

    def chat_guarded(messages, **kwargs):
        _count("input")
        allowed, safe_input = _screen(_user_text(messages), "INPUT")
        if not allowed:
            return BLOCKED_REPLY
        answer = original_chat(messages, **kwargs)
        if not answer:
            return answer
        _count("output")
        allowed, safe_answer = _screen(answer, "OUTPUT")
        return safe_answer if allowed else BLOCKED_REPLY

    # ── ② ai_client.chat_json（構造化出力） ─────────────────
    # 出力は JSON。値をマスクしても構造は保つ必要があり、BLOCK すると
    # 呼び出し側（agm/service.py・agm/workflow.py の計13か所）が
    # data=None を想定していないため機能が停止する（§B-2）。
    # 検証では「BLOCK が実際に何回起きるか」を数え、本番実装の要否を判断する。
    original_chat_json = ai_client.chat_json

    def chat_json_guarded(messages, **kwargs):
        _count("input")
        allowed, _ = _screen(_user_text(messages), "INPUT")
        if not allowed:
            # 呼び出し側は dict を期待している。空 dict なら status で拾える。
            return {}
        data = original_chat_json(messages, **kwargs)
        if not isinstance(data, dict):
            return data
        _count("output")
        allowed, _ = _screen(_json_text(data), "OUTPUT")
        if not allowed:
            return {}
        return _mask_values(data)

    # ── ③ response_store.record（履歴DB） ──────────────────
    # answer は ①② で検査済みだが、question は app.py が利用者入力を
    # そのまま渡すため、ここで検査しないと生の個人情報が保存される（§C-2）。
    original_record = response_store.record

    def record_guarded(feature, question, answer, **kwargs):
        _count("question")
        allowed, safe_question = _screen(question or "", "INPUT")
        if not allowed:
            safe_question = "（検査により非表示）"
        return original_record(feature, safe_question, answer, **kwargs)

    # ── ④ applog.event（ログ） ────────────────────────────
    original_event = applog.event

    def event_guarded(category, name, /, **fields):
        safe = {k: (mask_for_log(v) if isinstance(v, str) else v) for k, v in fields.items()}
        return original_event(category, name, **safe)

    ai_client.chat = chat_guarded
    ai_client.chat_json = chat_json_guarded
    response_store.record = record_guarded
    applog.event = event_guarded

    print("[wrap] 差し替え完了: ai_client.chat / ai_client.chat_json / "
          "response_store.record / applog.event")
    print(f"[wrap] ガードレール: {os.getenv('GUARDRAIL_ID', '(未設定)')} "
          f"/ {os.getenv('GUARDRAIL_VERSION', 'DRAFT')}")


def _json_text(data: dict) -> str:
    """JSON の文字列値だけを連結して検査対象にする（構造は検査に含めない）。"""
    found: list[str] = []

    def walk(node):
        if isinstance(node, str):
            found.append(node)
        elif isinstance(node, dict):
            for value in node.values():
                walk(value)
        elif isinstance(node, (list, tuple)):
            for value in node:
                walk(value)

    walk(data)
    return "\n".join(found)


def _mask_values(data):
    """JSON の**値だけ**をマスクし、キーと構造は保つ（§B-2）。

    構造ごとマスクすると呼び出し側の json パースが壊れ、機能が落ちる。
    """
    if isinstance(data, str):
        result = guard.check(data, source="OUTPUT")
        _count("text_units", result.text_units)
        if not result.ok or result.blocked:
            return "（検査により非表示）"
        return result.text or data
    if isinstance(data, dict):
        return {k: _mask_values(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_mask_values(v) for v in data]
    return data


def report() -> str:
    return ("[wrap] 検査回数 入力={input} 出力={output} 質問={question} / "
            "BLOCK={blocked} マスク={masked} エラー={error} / "
            "テキスト単位={text_units}").format(**STATS)


if __name__ != "__main__":
    # import された時点で差し替える（run_app_guarded.py から使う）。
    if os.getenv("GUARDRAIL_WRAP_AUTOINSTALL", "1") == "1":
        install()
