# -*- coding: utf-8 -*-
"""公開IR資料から D セット（正常業務文）を追加生成する。

なぜ実文書を使うか:
  誤検出率は「実際にアプリへ入る文章」でしか測れない。手書きの合成文だけだと
  文体が単調で、実運用より楽な数字が出る。data_external/hhhd_official_documents/
  にある統合報告書・決算資料・月次データは **公表済みの開示資料** なので、
  機密性の問題なく素材に使える。

使い方:
    python3 build_d_from_ir.py            # 既定で120件を追記
    python3 build_d_from_ir.py --limit 200 --out data/d_normal_ir.jsonl
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PDF_DIR = ROOT / "data_external" / "hhhd_official_documents"

# 抽出した文がそのまま使えるかの足切り。短すぎる断片や目次・ページ番号を落とす。
MIN_LEN = 30
MAX_LEN = 400
NOISE = re.compile(r"^[\s\d\.\-–—―・|｜]+$|^[0-9]{1,3}$|目次|ページ|Copyright|All Rights Reserved",
                   re.IGNORECASE)
# 日本語の文字（ひらがな・カタカナ・漢字）
JA = re.compile(r"[\u3040-\u30ff\u4e00-\u9fff]")


def japanese_enough(text: str, ratio: float = 0.35) -> bool:
    """日本語文字の比率で足切りする。

    統合報告書の一部PDFは埋め込みフォントの符号化の都合で、抽出すると
    "0TBLBBOE,PCF" のようなずれたASCIIになる。これを混ぜると誤検出率の
    分母が汚れるため、日本語がある程度含まれる文だけを採る。
    """
    if not text:
        return False
    return len(JA.findall(text)) / len(text) >= ratio


def sentences(text: str) -> list[str]:
    """日本語の文に割る。句点・改行の両方を区切りとして扱う。"""
    text = re.sub(r"[ \t　]+", " ", text)
    out: list[str] = []
    for block in text.split("\n"):
        block = block.strip()
        if not block:
            continue
        for piece in re.split(r"(?<=。)", block):
            piece = piece.strip()
            if (MIN_LEN <= len(piece) <= MAX_LEN
                    and not NOISE.search(piece)
                    and japanese_enough(piece)):
                out.append(piece)
    return out


def read_pdf(path: Path, max_pages: int = 12) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        print("pypdf が必要です: pip install pypdf", file=sys.stderr)
        raise SystemExit(2)
    import logging
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        reader = PdfReader(str(path))
    except Exception as exc:  # noqa: BLE001 - 壊れたPDFは飛ばす
        print(f"  読めません（{type(exc).__name__}）: {path.name}", file=sys.stderr)
        return ""
    parts = []
    for page in reader.pages[:max_pages]:
        try:
            parts.append(page.extract_text() or "")
        except Exception:  # noqa: BLE001
            continue
    return "\n".join(parts)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=120, help="生成する件数")
    parser.add_argument("--out", default="data/d_normal_ir.jsonl")
    parser.add_argument("--seed", type=int, default=20260828, help="抽出を再現可能にする")
    args = parser.parse_args()

    if not PDF_DIR.exists():
        print(f"公開IR資料が見つかりません: {PDF_DIR}", file=sys.stderr)
        return 2
    pdfs = sorted(PDF_DIR.glob("*.pdf"))
    print(f"対象PDF: {len(pdfs)}件")

    pool: list[tuple[str, str]] = []          # (出典ファイル名, 文)
    for path in pdfs:
        for line in sentences(read_pdf(path)):
            pool.append((path.name, line))
    print(f"抽出できた文: {len(pool)}件")
    if not pool:
        return 1

    random.Random(args.seed).shuffle(pool)
    # 同一PDFに偏らないよう、ファイルごとの採用上限を設ける。
    per_file_cap = max(3, args.limit // max(1, len(pdfs)) + 2)
    used: dict[str, int] = {}
    rows = []
    for name, line in pool:
        if len(rows) >= args.limit:
            break
        if used.get(name, 0) >= per_file_cap:
            continue
        used[name] = used.get(name, 0) + 1
        rows.append({
            "id": f"D-IR-{len(rows) + 1:03d}",
            "set": "D",
            "category": "公開IR資料",
            "text": line,
            "expect": "PASS",
            "expect_entity": "",
            "note": f"出典: {name[:60]}（公表済み開示資料）",
        })

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"{out}: {len(rows)}件を書き出しました（採用元 {len(used)}ファイル）")
    print("※ 公開資料のみを使用。data_internal（非公開）は参照していません。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
