# -*- coding: utf-8 -*-
"""Phase 3：検査つきでアプリを起動する。

通常のアプリ（既定 7860）とは別ポート・別データディレクトリで動かすため、
本番の runtime_data には一切触れない（§C-4）。

  PUBLIC_DATA_DIR を verify_guardrail/runtime に向けることで、
  ダミーの個人情報が本物の ai_response_history.json に混ざるのを防ぐ。
  settings.py:241 が RUNTIME_DATA_DIR をこの環境変数から解決している。

使い方:
    export GUARDRAIL_ID=xxxxxxxx
    python3 verify_guardrail/run_app_guarded.py

確認する場所:
    ① 画面表示（http://127.0.0.1:7899）
    ② verify_guardrail/runtime/ai_response_history.json  ← 保存前マスキングの実地確認
    ③ verify_guardrail/runtime/logs/                     ← ログのマスク
    ④ Word 出力（画面から書き出して中身を確認）
"""

from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

# ── 本番データから隔離する ─────────────────────────────
os.environ.setdefault("PUBLIC_DATA_DIR", str(HERE / "runtime"))
os.environ.setdefault("GRADIO_SERVER_PORT", "7899")
os.environ.setdefault("GRADIO_SERVER_NAME", "127.0.0.1")
# 検証中はパスワードを打たずに画面へ入る（本番では絶対に立てない設定）。
os.environ.setdefault("ALLOW_NO_AUTH", "true")
# 収集パイプラインが検証中に走ると外部APIを叩くので止める。
os.environ.setdefault("ENABLE_PIPELINE_REFRESH", "false")

(HERE / "runtime").mkdir(parents=True, exist_ok=True)

for path in (str(HERE), str(ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

if not os.getenv("GUARDRAIL_ID"):
    print("GUARDRAIL_ID が未設定です。setup_guardrail.py create の出力を参照してください。",
          file=sys.stderr)
    raise SystemExit(2)

import wrap  # noqa: E402,F401  ← import した時点で関数を差し替える

print(f"[run] データ置き場 : {os.environ['PUBLIC_DATA_DIR']}")
print(f"[run] ポート       : {os.environ['GRADIO_SERVER_PORT']}")
print("[run] 本番の runtime_data には書き込みません。")
print("[run] 終了時に検査回数を表示します（Ctrl+C）。\n")

try:
    # app.py を通常どおり __main__ として実行する。差し替えは既に済んでいる。
    runpy.run_path(str(ROOT / "app.py"), run_name="__main__")
finally:
    print("\n" + wrap.report())
