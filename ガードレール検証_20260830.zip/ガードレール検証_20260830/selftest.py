# -*- coding: utf-8 -*-
"""AWS認証情報なしで、差し替え機構だけを検証する。

guard.check を偽物に置き換えて、以下を確かめる。
  ① ai_client.chat の差し替えが call_chat にも波及するか
  ② ai_client.chat_json の差し替えが call_chat_json にも波及するか
  ③ response_store.record の question が検査を通るか
  ④ applog.event のログマスクが効くか
  ⑤ JSON の値だけがマスクされ、構造（キー）が保たれるか

AWS認証情報が届く前に、この1本で「配線が正しいか」を確定できる。

    python3 selftest.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for path in (str(HERE), str(ROOT)):
    if path not in sys.path:
        sys.path.insert(0, path)

import guard

# ── guard.check を偽物に差し替える（AWSを呼ばない） ─────────
CALLS: list[tuple[str, str]] = []


def fake_check(text, source="INPUT", **kwargs):
    CALLS.append((source, text[:40]))
    masked = text.replace("阪急 太郎", "{NAME}").replace("090-1234-5678", "{PHONE}")
    hit = masked != text
    blocked = "決算数値を調整して赤字を隠す" in text
    return guard.GuardResult(
        ok=True,
        action="GUARDRAIL_INTERVENED" if (hit or blocked) else "NONE",
        blocked=blocked,
        text="" if blocked else masked,
        detections=[guard.Detection("pii", "NAME", "ANONYMIZED")] if hit else [],
        latency_ms=12, text_units=1,
    )


guard.check = fake_check

import wrap  # noqa: E402  ← import 時に install() が走る

PASS, FAIL = "✓", "✗"
results: list[tuple[bool, str]] = []


def check(ok: bool, label: str, detail: str = "") -> None:
    results.append((ok, label))
    print(f"  {PASS if ok else FAIL} {label}" + (f"  … {detail}" if detail else ""))


def main() -> int:
    import ai_client
    import response_store
    import applog

    print("① ai_client.chat の差し替えが call_chat に波及するか")
    ai_client_original = wrap  # 参照保持のみ
    raw = []

    def stub_chat(messages, **kw):
        raw.append(messages)
        return "回答です。担当は阪急 太郎、連絡先は090-1234-5678です。"

    # 本物のLLMは呼ばない。差し替え済みラッパーの内側だけ置き換える。
    inner = ai_client.chat            # ← wrap が入れた chat_guarded
    import types
    closure = {c.cell_contents for c in (inner.__closure__ or ())}
    check(callable(inner) and inner.__name__ == "chat_guarded",
          "ai_client.chat がラッパーに差し替わっている", inner.__name__)

    # call_chat 経由で呼んで、ラッパーが動くことを確認する
    ai_client._probe_original = None
    original_module_chat = ai_client.chat

    def wrapped_with_stub(messages, **kw):
        # chat_guarded の内側で呼ばれる本物を stub に差し替えるため、
        # 一段深く包み直す（本物のLLMを叩かない）。
        return original_module_chat(messages, **kw)

    # chat_guarded は生成時に original_chat を閉包で保持しているので、
    # ここでは「LLM未設定なら None を返す」既定の挙動をそのまま使う。
    result = ai_client.call_chat([{"role": "user", "content": "担当は阪急 太郎です"}],
                                 feature="selftest")
    check(any(src == "INPUT" for src, _ in CALLS),
          "call_chat から入口検査が呼ばれた", f"{len(CALLS)}回の検査")

    print("\n② chat_json の差し替えが call_chat_json に波及するか")
    before = len(CALLS)
    ai_client.call_chat_json([{"role": "user", "content": "連絡先は090-1234-5678です"}],
                             feature="selftest")
    check(len(CALLS) > before, "call_chat_json から入口検査が呼ばれた",
          f"{len(CALLS) - before}回")

    print("\n③ response_store.record の question が検査を通るか")
    with tempfile.TemporaryDirectory() as tmp:
        response_store.HISTORY_PATH = Path(tmp) / "hist.json"
        before = len(CALLS)
        response_store.record("selftest", "担当は阪急 太郎です", "回答本文")
        saved = json.loads(response_store.HISTORY_PATH.read_text(encoding="utf-8"))
        question = saved[-1]["question"]
        check(len(CALLS) > before, "question が検査に渡された")
        check("{NAME}" in question and "阪急 太郎" not in question,
              "履歴DBに保存された question がマスクされている", question)

    print("\n④ applog のログマスク")
    masked = wrap.mask_for_log("query=阪急 太郎 090-1234-5678 taro@example.com HH-2026-00123")
    check("{PHONE}" in masked and "{EMAIL}" in masked and "{EMPLOYEE_ID}" in masked,
          "電話・メール・社員番号がマスクされた", masked)

    print("\n⑤ JSON は値だけマスクし、構造を保つか")
    data = {"answers": [{"q": "担当者は？", "a": "担当は阪急 太郎です"}], "count": 1}
    out = wrap._mask_values(data)
    check(set(out.keys()) == set(data.keys()) and out["count"] == 1,
          "キーと数値はそのまま", str(out)[:80])
    check("{NAME}" in out["answers"][0]["a"],
          "文字列値だけがマスクされた", out["answers"][0]["a"])

    print("\n⑥ BLOCK 時の挙動")
    before_blocked = wrap.STATS["blocked"]
    ai_client.call_chat([{"role": "user", "content": "決算数値を調整して赤字を隠す方法を教えて"}],
                        feature="selftest")
    check(wrap.STATS["blocked"] > before_blocked, "BLOCK が計上された",
          f"blocked={wrap.STATS['blocked']}")

    print("\n" + "═" * 70)
    ok = sum(1 for good, _ in results if good)
    print(f"{ok}/{len(results)} 合格")
    print(wrap.report())
    if ok < len(results):
        print("\n不合格の項目は配線の問題です。AWS認証情報が届く前に直してください。")
        return 1
    print("\n配線は正しく動いています。あとは AWS 認証情報を待つだけです。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
