# -*- coding: utf-8 -*-
"""Bedrock Guardrails（ApplyGuardrail）を呼ぶだけの薄い層。

アプリ本体からは独立している。ここが依存するのは boto3 と標準ライブラリのみで、
gradio_app_0825 のモジュールは一切 import しない（検証がアプリを壊さないため）。

設計上の前提（検証計画 §B-1）:
  ApplyGuardrail は概ね 1,000 文字＝1テキスト単位の従量課金である。
  したがって「毎回プロンプト全体を通す」設計は採らない。呼び出し側が
  「利用者入力」「最終出力」だけを毎回、素材（RAG・添付・ウェブ）は
  取得時に1回だけ通す。text_units はその実測のために必ず記録する。
"""

from __future__ import annotations

import math
import os
import time
from dataclasses import dataclass, field

try:
    import boto3
    from botocore.config import Config as BotoConfig
    from botocore.exceptions import BotoCoreError, ClientError
except ImportError:  # boto3 未導入の環境でも import だけは通す
    boto3 = None
    BotoConfig = None
    BotoCoreError = ClientError = Exception


DEFAULT_REGION = os.getenv("GUARDRAIL_REGION", "ap-northeast-1")
DEFAULT_ID = os.getenv("GUARDRAIL_ID", "")
DEFAULT_VERSION = os.getenv("GUARDRAIL_VERSION", "DRAFT")

# ApplyGuardrail の 1 回あたり上限。超える入力は分割して送る。
# 正確な上限は初回実行で確認する（ValidationException のメッセージに出る）。
CHUNK_CHARS = int(os.getenv("GUARDRAIL_CHUNK_CHARS", "20000"))

# INTERVENTIONS: 検出されたものだけ返る（本番と同じ挙動）
# FULL:          未検出の項目も detected=false 付きで返る（調査用）
# 検証では FULL にすると「何を評価して何を見逃したか」まで分かる。
OUTPUT_SCOPE = os.getenv("GUARDRAIL_OUTPUT_SCOPE", "INTERVENTIONS")


@dataclass
class Detection:
    """1件の検出。policy はどのフィルタが反応したかを示す。"""
    policy: str          # pii / regex / content / topic / word / grounding
    kind: str            # NAME, MISCONDUCT, マイナンバー ...
    action: str          # BLOCKED / ANONYMIZED / NONE
    detail: str = ""


@dataclass
class GuardResult:
    ok: bool                       # API 呼び出し自体が成功したか
    action: str = "NONE"           # NONE / GUARDRAIL_INTERVENED / ERROR
    blocked: bool = False          # 回答を止めるべきか
    text: str = ""                 # マスク後のテキスト（BLOCK時は空）
    detections: list[Detection] = field(default_factory=list)
    latency_ms: int = 0
    text_units: int = 0
    error: str = ""
    raw: dict = field(default_factory=dict)

    @property
    def kinds(self) -> list[str]:
        return [d.kind for d in self.detections]

    @property
    def intervened(self) -> bool:
        """検出が1件でもあったか（BLOCK・マスクの両方を含む）。"""
        return self.action == "GUARDRAIL_INTERVENED" or bool(self.detections)


_CLIENT = None
_CLIENT_REGION = ""


def client(region: str = ""):
    """bedrock-runtime クライアント。region ごとに1つだけ作って使い回す。"""
    global _CLIENT, _CLIENT_REGION
    if boto3 is None:
        raise RuntimeError(
            "boto3 が未導入です。`pip install boto3` を実行してください。"
        )
    region = region or DEFAULT_REGION
    if _CLIENT is None or _CLIENT_REGION != region:
        _CLIENT = boto3.client(
            "bedrock-runtime",
            region_name=region,
            config=BotoConfig(retries={"max_attempts": 2, "mode": "standard"},
                              connect_timeout=5, read_timeout=30),
        )
        _CLIENT_REGION = region
    return _CLIENT


def text_units(text: str) -> int:
    """課金単位の見積り。1,000文字＝1単位として切り上げる。"""
    return max(1, math.ceil(len(text or "") / 1000))


def _hit(entry: dict) -> bool:
    """その項目が実際に「検出された」ものかを判定する。

    outputScope=FULL では **未検出の項目も** detected=false 付きで返る
    （botocore のモデルで確認済み）。これを数えると誤検出が水増しされるため、
    detected が明示的に false のものは落とす。キー自体が無い場合
    （INTERVENTIONS スコープ）は検出とみなす。
    """
    return entry.get("detected", True) is not False


def _usage_units(usage: dict) -> int:
    """実際に課金された単位数を合算する。

    botocore のモデル上、usage に textUnits というキーは存在せず、
    topicPolicyUnits / contentPolicyUnits / wordPolicyUnits /
    sensitiveInformationPolicyUnits / contextualGroundingPolicyUnits …
    のようにポリシー別に返る。無償枠分（*FreeUnits）は費用に含めない。
    """
    return sum(int(value) for key, value in usage.items()
               if key.endswith("Units") and "Free" not in key
               and isinstance(value, (int, float)))


def _collect(assessments: list[dict]) -> list[Detection]:
    """ApplyGuardrail の assessments を Detection の一覧へ畳み込む。

    キー名は botocore の bedrock-runtime モデル（API版 2023-09-30）で確認済み。
      sensitiveInformationPolicy.piiEntities[]  : match / type / action / detected
      sensitiveInformationPolicy.regexes[]      : name / match / regex / action / detected
      contentPolicy.filters[]                   : type / confidence / filterStrength / action / detected
      topicPolicy.topics[]                      : name / type / action / detected
      wordPolicy.customWords[]                  : match / action / detected
      wordPolicy.managedWordLists[]             : match / type / action / detected
      contextualGroundingPolicy.filters[]       : type / threshold / score / action / detected
    それでも版差に備え、読み取りはすべて .get() で行う。
    """
    found: list[Detection] = []
    for item in assessments or []:
        sensitive = item.get("sensitiveInformationPolicy") or {}
        for pii in sensitive.get("piiEntities") or []:
            if not _hit(pii):
                continue
            found.append(Detection("pii", pii.get("type", "?"),
                                   pii.get("action", "?"), pii.get("match", "")[:60]))
        for rex in sensitive.get("regexes") or []:
            if not _hit(rex):
                continue
            found.append(Detection("regex", rex.get("name", "?"),
                                   rex.get("action", "?"), rex.get("match", "")[:60]))
        for flt in (item.get("contentPolicy") or {}).get("filters") or []:
            if not _hit(flt):
                continue
            found.append(Detection("content", flt.get("type", "?"),
                                   flt.get("action", "?"),
                                   f"confidence={flt.get('confidence', '?')}"))
        for topic in (item.get("topicPolicy") or {}).get("topics") or []:
            if not _hit(topic):
                continue
            found.append(Detection("topic", topic.get("name", "?"),
                                   topic.get("action", "?"), topic.get("type", "")))
        word_policy = item.get("wordPolicy") or {}
        for word in word_policy.get("customWords") or []:
            if not _hit(word):
                continue
            found.append(Detection("word", word.get("match", "?"),
                                   word.get("action", "?"), "custom"))
        for word in word_policy.get("managedWordLists") or []:
            if not _hit(word):
                continue
            found.append(Detection("word", word.get("match", "?"),
                                   word.get("action", "?"), word.get("type", "managed")))
        for flt in (item.get("contextualGroundingPolicy") or {}).get("filters") or []:
            if not _hit(flt):
                continue
            found.append(Detection("grounding", flt.get("type", "?"),
                                   flt.get("action", "?"),
                                   f"score={flt.get('score', '?')}"))
    return found


def _apply_once(text: str, source: str, guardrail_id: str,
                version: str, region: str) -> GuardResult:
    started = time.monotonic()
    try:
        response = client(region).apply_guardrail(
            guardrailIdentifier=guardrail_id,
            guardrailVersion=version,
            source=source,                       # INPUT / OUTPUT
            content=[{"text": {"text": text}}],
            outputScope=OUTPUT_SCOPE,            # INTERVENTIONS / FULL
        )
    except (ClientError, BotoCoreError, RuntimeError) as exc:
        # 検査できないときは通さない（fail-closed）。判断は呼び出し側に返す。
        return GuardResult(ok=False, action="ERROR", blocked=True,
                           error=f"{type(exc).__name__}: {exc}"[:400],
                           latency_ms=round((time.monotonic() - started) * 1000),
                           text_units=text_units(text))
    elapsed = round((time.monotonic() - started) * 1000)
    action = response.get("action", "NONE")
    outputs = response.get("outputs") or []
    masked = outputs[0].get("text", "") if outputs else ""
    detections = _collect(response.get("assessments") or [])
    # BLOCK されたかは outputs の空/非空では判定できない。
    # コンテンツフィルタや拒否トピックが BLOCK すると、outputs には
    # blockedInputMessaging（「Sorry, ...」）が入って **非空** になるため、
    # 「空ならブロック」と判定すると全て未ブロック扱いになる（実機で確認）。
    # 各検出の action が BLOCKED かどうかで判定する。
    blocked = (any(d.action == "BLOCKED" for d in detections)
               or (action == "GUARDRAIL_INTERVENED" and not masked))
    return GuardResult(
        ok=True, action=action, blocked=blocked,
        text=masked or ("" if blocked else text),
        detections=detections, latency_ms=elapsed,
        text_units=_usage_units(response.get("usage") or {}) or text_units(text),
        raw=response,
    )


def check(text: str, source: str = "INPUT", *, guardrail_id: str = "",
          version: str = "", region: str = "") -> GuardResult:
    """テキストを検査する。長文は CHUNK_CHARS ごとに分割して送り、結果を合算する。

    source は INPUT（利用者からアプリへ）か OUTPUT（アプリから利用者へ）。
    どちらで送るかで適用されるフィルタの強度設定が変わる。
    """
    text = text or ""
    guardrail_id = guardrail_id or DEFAULT_ID
    version = version or DEFAULT_VERSION
    if not guardrail_id:
        return GuardResult(ok=False, action="ERROR", blocked=True,
                           error="GUARDRAIL_ID が未設定です（環境変数か引数で指定）")
    if not text.strip():
        return GuardResult(ok=True, action="NONE", text=text, text_units=0)

    chunks = [text[i:i + CHUNK_CHARS] for i in range(0, len(text), CHUNK_CHARS)] or [text]
    merged = GuardResult(ok=True, text="")
    parts: list[str] = []
    for chunk in chunks:
        one = _apply_once(chunk, source, guardrail_id, version, region)
        merged.latency_ms += one.latency_ms
        merged.text_units += one.text_units
        merged.detections.extend(one.detections)
        if not one.ok:
            one.detections = merged.detections
            one.latency_ms = merged.latency_ms
            one.text_units = merged.text_units
            return one
        if one.blocked:
            one.detections = merged.detections
            one.latency_ms = merged.latency_ms
            one.text_units = merged.text_units
            return one
        if one.action == "GUARDRAIL_INTERVENED":
            merged.action = "GUARDRAIL_INTERVENED"
        parts.append(one.text)
        merged.raw = one.raw
    merged.text = "".join(parts)
    return merged
