# -*- coding: utf-8 -*-
"""Phase 2：ラッパー＋実AWSガードレールの結合検証。

LLM本体は呼ばない（内側の chat をスタブに差し替えてから wrap を読み込む）。
確認するのは「アプリの関数を通したとき、実際のガードレールが効くか」の一点。

    GUARDRAIL_ID=<推奨構成のID> python3 phase2_test.py
"""
from __future__ import annotations
import os, sys, json, time, tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
for p in (str(HERE), str(ROOT)):
    if p not in sys.path: sys.path.insert(0, p)

import ai_client, response_store, applog

# ── 内側のLLMをスタブ化してから wrap を入れる ─────────────
LLM_ANSWER = ("ご確認ください。担当は宝塚 花子、連絡先は080-0000-1111、"
              "メールは hanako.t@example.co.jp です。社員番号は HH-2019-08842。")
def stub_chat(messages, **kw):  return LLM_ANSWER
def stub_chat_json(messages, **kw): return {"answers":[{"q":"担当は？","a":LLM_ANSWER}],"count":1}
ai_client.chat, ai_client.chat_json = stub_chat, stub_chat_json

import wrap   # ← ここで install() が走り、上のスタブを「本物」として包む

OK, NG = "✓", "✗"
results = []
def check(cond, label, detail=""):
    results.append(cond); print(f"  {OK if cond else NG} {label}" + (f"  … {detail}" if detail else ""))

def main() -> int:
    if not os.getenv("GUARDRAIL_ID"):
        print("GUARDRAIL_ID を指定してください", file=sys.stderr); return 2
    print(f"ガードレール: {os.getenv('GUARDRAIL_ID')} / {os.getenv('GUARDRAIL_REGION','ap-northeast-1')}\n")

    print("① 自由文（call_chat）— 入口で利用者入力、出口で回答を検査")
    t0 = time.monotonic()
    r = ai_client.call_chat(
        [{"role":"user","content":"担当者は阪急 太郎です。連絡先は090-1234-5678。本人確認番号は123456789012。"}],
        feature="phase2")
    el = (time.monotonic()-t0)*1000
    print(f"     回答: {r.content}")
    check(r.status=="ok", "呼び出しが成功した", r.status)
    check("{NAME}" in (r.content or "") or "{PHONE}" in (r.content or ""),
          "出口検査で回答内のPIIがマスクされた")
    check("宝塚 花子" not in (r.content or ""), "元の氏名が残っていない")
    print(f"     往復時間: {el:.0f}ms（入口＋出口の2回分を含む）")

    print("\n② 構造化出力（call_chat_json）— 値だけマスクし構造を保つ")
    r2 = ai_client.call_chat_json([{"role":"user","content":"担当者を教えてください。"}], feature="phase2")
    print(f"     data: {json.dumps(r2.data, ensure_ascii=False)[:150]}")
    check(isinstance(r2.data, dict) and "answers" in r2.data, "キー構造が保たれた")
    check(r2.data.get("count")==1, "数値がそのまま残った")
    a = (r2.data.get("answers") or [{}])[0].get("a","")
    check("宝塚 花子" not in a, "文字列値の氏名がマスクされた", a[:60])

    print("\n③ 履歴DB（response_store.record）— question の保存前マスキング")
    with tempfile.TemporaryDirectory() as tmp:
        response_store.HISTORY_PATH = Path(tmp)/"hist.json"
        response_store.record("phase2",
            "阪急 太郎（HH-2026-00123、090-1234-5678）の件で相談です。", "回答本文")
        saved = json.loads(response_store.HISTORY_PATH.read_text(encoding="utf-8"))[-1]
        print(f"     保存された question: {saved['question']}")
        check("阪急 太郎" not in saved["question"], "氏名がマスクされて保存された")
        check("090-1234-5678" not in saved["question"], "電話番号がマスクされて保存された")

    print("\n④ ログ（applog.event）— ローカル正規表現マスク")
    m = wrap.mask_for_log("query=阪急 太郎 090-1234-5678 taro@example.com HH-2026-00123")
    check("{PHONE}" in m and "{EMAIL}" in m and "{EMPLOYEE_ID}" in m, "電話・メール・社員番号をマスク", m)

    print("\n⑤ 業務文が壊れないか（駅名・数値・役職）")
    ai_client.chat = lambda messages, **kw: (
        "西宮北口駅の乗降人員は前年同期比103.2%でした。財務部長より説明がありました。")
    import importlib; importlib.reload(wrap)
    r3 = ai_client.call_chat([{"role":"user","content":"西宮北口駅の乗降人員を教えてください。"}], feature="phase2")
    print(f"     回答: {r3.content}")
    check("西宮北口駅" in (r3.content or ""), "駅名が改変されていない")
    check("103.2%" in (r3.content or ""), "数値が改変されていない")

    print("\n" + "═"*66)
    print(f"{sum(results)}/{len(results)} 合格")
    print(wrap.report())
    return 0 if all(results) else 1

if __name__ == "__main__":
    raise SystemExit(main())
