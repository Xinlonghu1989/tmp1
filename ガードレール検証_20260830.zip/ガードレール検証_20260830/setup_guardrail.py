# -*- coding: utf-8 -*-
"""ガードレールを作成・更新・一覧・削除する。

設定はコンソール手作業ではなく config/*.json から作る。手作業だと構成を再現できず、
しきい値を調整するたびに「前回と何が違うのか」が分からなくなるため。

使い方:
    python3 setup_guardrail.py check                     # 疎通と権限の確認だけ
    python3 setup_guardrail.py create config/guardrail_01_standard.json
    python3 setup_guardrail.py profiles                  # STANDARDティア用プロファイル
    python3 setup_guardrail.py list
    python3 setup_guardrail.py delete <guardrailId>
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

REGION = os.getenv("GUARDRAIL_REGION", "ap-northeast-1")


def _client():
    try:
        import boto3
    except ImportError:
        print("boto3 が未導入です: pip install boto3", file=sys.stderr)
        raise SystemExit(2)
    return boto3.client("bedrock", region_name=REGION)


def _runtime():
    import boto3
    return boto3.client("bedrock-runtime", region_name=REGION)


def cmd_check() -> int:
    """Phase 0-1。認証情報・リージョン・権限が揃っているかを順に確かめる。"""
    print(f"リージョン: {REGION}")
    try:
        import boto3
    except ImportError:
        print("✗ boto3 が未導入です: pip install boto3")
        return 2
    session = boto3.Session()
    creds = session.get_credentials()
    if creds is None:
        print("✗ AWS認証情報が見つかりません。")
        print("  環境変数 AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY、")
        print("  または ~/.aws/credentials、あるいは実行環境のIAMロールが必要です。")
        print("  ※ アプリの ANTHROPIC_API_KEY とは別系統の認証情報です（README §1 参照）。")
        return 1
    print(f"✓ AWS認証情報あり（方式: {creds.method}）")
    try:
        ident = boto3.client("sts", region_name=REGION).get_caller_identity()
        print(f"✓ アカウント: {ident['Account']} / 実行者: {ident['Arn']}")
    except Exception as exc:  # noqa: BLE001
        print(f"△ STSで実行者を確認できません: {type(exc).__name__}")
    try:
        found = _client().list_guardrails(maxResults=5)
        print(f"✓ bedrock:ListGuardrails 可（既存 {len(found.get('guardrails', []))} 件）")
    except Exception as exc:  # noqa: BLE001
        print(f"✗ Guardrails APIを呼べません: {type(exc).__name__}: {exc}")
        print("  リージョン未提供、または権限（bedrock:ListGuardrails）不足の可能性があります。")
        return 1
    print("\n次: python3 setup_guardrail.py create config/guardrail_01_standard.json")
    return 0


def cmd_create(path: str) -> int:
    body = json.loads(Path(path).read_text(encoding="utf-8"))
    body = {k: v for k, v in body.items() if not k.startswith("_")}
    try:
        result = _client().create_guardrail(**body)
    except Exception as exc:  # noqa: BLE001
        print(f"✗ 作成に失敗: {type(exc).__name__}: {exc}", file=sys.stderr)
        print("\nValidationException の場合、config のキー名が API の版と違う可能性があります。"
              "\nエラーメッセージが指すフィールドを config/*.json 側で直してください。", file=sys.stderr)
        return 1
    gid = result["guardrailId"]
    print(f"✓ 作成しました: {body['name']}")
    print(f"  guardrailId : {gid}")
    print(f"  version     : {result.get('version', 'DRAFT')}")
    print(f"\n以降の実行で使う環境変数:\n  export GUARDRAIL_ID={gid}\n  export GUARDRAIL_VERSION=DRAFT")
    return 0


def cmd_profiles() -> int:
    """クロスリージョン推論プロファイルの一覧。

    STANDARD ティア（日本語を扱うなら必須）は crossRegionConfig を要求し、
    そこに渡す guardrailProfileIdentifier はリージョンごとに異なる。
    ここで得た ID を config/*.json の REPLACE_ME_... と差し替える。
    """
    try:
        found = _client().list_guardrail_profiles(maxResults=50)
    except AttributeError:
        print("この boto3 には list_guardrail_profiles がありません。"
              "`pip install -U boto3` で更新するか、コンソールで確認してください。")
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"✗ 取得できません: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    items = found.get("guardrailProfiles", [])
    if not items:
        print("プロファイルがありません。このリージョンでは STANDARD ティアを"
              "使えない可能性があります。")
        return 1
    for item in items:
        print(f"{item.get('guardrailProfileId','?'):40} {item.get('guardrailProfileArn','')}")
    print("\n上記のIDを config/guardrail_02_strict.json と guardrail_03_tuned.json の"
          "\ncrossRegionConfig.guardrailProfileIdentifier に設定してください。")
    return 0


def cmd_list() -> int:
    for item in _client().list_guardrails(maxResults=50).get("guardrails", []):
        print(f"{item.get('id','?'):24} {item.get('name','?'):28} "
              f"{item.get('status','?'):10} {item.get('version','?')}")
    return 0


def cmd_delete(gid: str) -> int:
    _client().delete_guardrail(guardrailIdentifier=gid)
    print(f"✓ 削除しました: {gid}")
    return 0


def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 1
    action = args[0]
    if action == "check":
        return cmd_check()
    if action == "create" and len(args) > 1:
        return cmd_create(args[1])
    if action == "list":
        return cmd_list()
    if action == "profiles":
        return cmd_profiles()
    if action == "delete" and len(args) > 1:
        return cmd_delete(args[1])
    print(__doc__)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
