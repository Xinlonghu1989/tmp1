# -*- coding: utf-8 -*-
"""Phase 1：ダミーデータを ApplyGuardrail に流し、守備範囲を実測する。

アプリのモジュールは一切 import しない。ここで出る数字が、スライドの
「約8割」を置き換える実測値になる。

集計方針（検証計画 §B-4）:
  単一の「8割」は出さない。**カテゴリ別の検出率**を主とする。
  総合値はカテゴリの重み（想定利用頻度）を weights.json で与えたときだけ計算する。
  重みなしの単純平均はデータの構成比が変わるだけで動いてしまい、意味を持たない。

使い方:
    export GUARDRAIL_ID=xxxxxxxx
    python3 probe.py                                   # A〜D 全件
    python3 probe.py --data data/min.jsonl             # 特定のセットだけ
    python3 probe.py --label 構成2強化 --source BOTH
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import guard  # noqa: E402

HERE = Path(__file__).resolve().parent
DEFAULT_DATA = ["data/a_pii.jsonl", "data/b_harmful.jsonl",
                "data/c_secret.jsonl", "data/d_normal.jsonl",
                "data/d_normal_ir.jsonl"]

# 1,000テキスト単位あたりの単価（USD）。実際の価格表に合わせて上書きする。
UNIT_PRICE_USD = float(os.getenv("GUARDRAIL_UNIT_PRICE_USD", "0.15"))


def load(paths: list[str]) -> list[dict]:
    rows = []
    for name in paths:
        path = HERE / name if not Path(name).is_absolute() else Path(name)
        if not path.exists():
            print(f"（省略）{name} が見つかりません", file=sys.stderr)
            continue
        with path.open(encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    return rows


def judge(record: dict, result: guard.GuardResult) -> str:
    """期待と実測を突き合わせて判定する。

    PASS を期待する行（D セットと C-NEG）で検出が出れば「誤検出」。
    MASK/BLOCK を期待する行で検出が出なければ「見逃し」。
    """
    expect = record.get("expect", "")
    if not result.ok:
        return "エラー"
    if expect == "PASS":
        return "誤検出" if result.intervened else "正解"
    if not result.intervened:
        return "見逃し"
    if expect == "BLOCK" and not result.blocked:
        return "検出（BLOCKではない）"
    return "正解"


def summarize(rows: list[dict], label: str) -> str:
    """カテゴリ別の検出率・誤検出率・遅延・費用を Markdown で返す。"""
    by_cat: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        by_cat[(row["set"], row["category"])].append(row)

    lines = [f"# ガードレール検証サマリ — {label}", ""]
    lines += [f"- 件数: {len(rows)}",
              f"- 構成: `{os.getenv('GUARDRAIL_ID', '(未設定)')}` / "
              f"`{os.getenv('GUARDRAIL_VERSION', 'DRAFT')}` / "
              f"`{os.getenv('GUARDRAIL_REGION', 'ap-northeast-1')}`", ""]

    # ── 検出率（A/B/C の陽性行） ───────────────────────
    lines += ["## 1. カテゴリ別の検出率（検出されるべき行）", "",
              "| セット | カテゴリ | 件数 | 正解 | 見逃し | 検出率 |", "|---|---|---:|---:|---:|---:|"]
    pos_total = pos_ok = 0
    for (dataset, category), items in sorted(by_cat.items()):
        if dataset == "D" or all(i["expect"] == "PASS" for i in items):
            continue
        ok = sum(1 for i in items if i["判定"] == "正解")
        miss = sum(1 for i in items if i["判定"] == "見逃し")
        pos_total += len(items)
        pos_ok += ok
        rate = f"{ok / len(items) * 100:.0f}%" if items else "-"
        lines.append(f"| {dataset} | {category} | {len(items)} | {ok} | {miss} | **{rate}** |")
    if pos_total:
        lines += ["", f"合計 {pos_ok}/{pos_total}（{pos_ok / pos_total * 100:.1f}%）"
                      " ※ この合計はテストデータの構成比に依存するため、"
                      "対外的な数字にはカテゴリの重み付けを合意してから用いること。"]

    # ── 誤検出率（PASS を期待する行） ──────────────────
    neg = [r for r in rows if r["expect"] == "PASS"]
    fp = [r for r in neg if r["判定"] == "誤検出"]
    lines += ["", "## 2. 誤検出率（止まってはいけない行）", ""]
    if neg:
        lines.append(f"**{len(fp)}/{len(neg)} = {len(fp) / len(neg) * 100:.1f}%**"
                     f"（合格ライン 2% 以下）")
        if fp:
            lines += ["", "| ID | カテゴリ | 反応したフィルタ | 本文（先頭60字） |", "|---|---|---|---|"]
            for row in fp[:40]:
                lines.append(f"| {row['id']} | {row['category']} | {row['検出']} | "
                             f"{row['text'][:60].replace('|', '｜')} |")
            if len(fp) > 40:
                lines.append(f"| … | 他 {len(fp) - 40} 件 | | |")
    else:
        lines.append("（PASS 期待の行がありません）")

    # ── 見逃し一覧 ──────────────────────────────────
    miss = [r for r in rows if r["判定"] == "見逃し"]
    lines += ["", "## 3. 見逃し一覧（＝補完開発の対象）", ""]
    if miss:
        lines += ["| ID | カテゴリ | 期待 | 本文（先頭60字） |", "|---|---|---|---|"]
        for row in miss[:60]:
            lines.append(f"| {row['id']} | {row['category']} | {row['expect_entity']} | "
                         f"{row['text'][:60].replace('|', '｜')} |")
        if len(miss) > 60:
            lines.append(f"| … | 他 {len(miss) - 60} 件 | | |")
    else:
        lines.append("見逃しはありません。")

    # ── 遅延・費用 ──────────────────────────────────
    lat = sorted(r["latency_ms"] for r in rows if r["latency_ms"])
    units = sum(r["text_units"] for r in rows)
    lines += ["", "## 4. 遅延と費用", ""]
    if lat:
        p50 = statistics.median(lat)
        p95 = lat[max(0, int(len(lat) * 0.95) - 1)]
        lines += [f"- 1回あたり遅延: p50 **{p50:.0f}ms** / p95 **{p95:.0f}ms** / 最大 {lat[-1]:.0f}ms",
                  f"- 合格ライン p95 300ms 以下 → **{'合格' if p95 <= 300 else '未達'}**"]
    lines += [f"- テキスト単位の合計: {units}",
              f"- 概算費用: ${units / 1000 * UNIT_PRICE_USD:.4f}"
              f"（1,000単位あたり ${UNIT_PRICE_USD} と仮定。実価格に合わせて "
              "`GUARDRAIL_UNIT_PRICE_USD` を指定）"]

    errs = [r for r in rows if r["判定"] == "エラー"]
    if errs:
        lines += ["", "## 5. API エラー", ""]
        for row in errs[:10]:
            lines.append(f"- {row['id']}: {row['error'][:160]}")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", action="append", help="JSONL（複数可）")
    parser.add_argument("--label", default=os.getenv("GUARDRAIL_LABEL", "構成未指定"))
    parser.add_argument("--source", default="INPUT", choices=["INPUT", "OUTPUT", "BOTH"])
    parser.add_argument("--out-dir", default="result")
    parser.add_argument("--limit", type=int, default=0, help="先頭N件だけ試す")
    parser.add_argument("--dry-run", action="store_true",
                        help="AWSを呼ばず、config の正規表現だけで実行する（配管確認用）")
    parser.add_argument("--config", default="config/guardrail_02_strict.json",
                        help="--dry-run で使う config")
    args = parser.parse_args()

    if args.dry_run:
        import local_detector
        patterns = local_detector.load_patterns(HERE / args.config)
        guard.check = local_detector.make_check(patterns)
        print(f"[dry-run] AWSは呼びません。{args.config} の正規表現 {len(patterns)}件で実行します。")
        args.label = f"dryrun_{args.label}"
    elif not os.getenv("GUARDRAIL_ID"):
        print("GUARDRAIL_ID が未設定です。setup_guardrail.py create の出力を参照してください。",
              file=sys.stderr)
        return 2

    records = load(args.data or DEFAULT_DATA)
    if args.limit:
        records = records[:args.limit]
    if not records:
        print("テストデータがありません。", file=sys.stderr)
        return 1
    sources = ["INPUT", "OUTPUT"] if args.source == "BOTH" else [args.source]
    print(f"{len(records)}件 × {len(sources)}方向 = {len(records) * len(sources)}回 実行します")

    rows = []
    for index, record in enumerate(records, 1):
        for source in sources:
            result = guard.check(record["text"], source=source)
            row = dict(record)
            row.update({
                "source": source,
                "action": result.action,
                "blocked": result.blocked,
                "検出": ";".join(f"{d.policy}:{d.kind}" for d in result.detections) or "-",
                "masked": (result.text or "")[:300],
                "latency_ms": result.latency_ms,
                "text_units": result.text_units,
                "error": result.error,
            })
            row["判定"] = judge(record, result)
            rows.append(row)
        if index % 20 == 0:
            print(f"  {index}/{len(records)} …")

    out_dir = HERE / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = args.label.replace("/", "_").replace(" ", "_")
    csv_path = out_dir / f"probe_{stem}.csv"
    fields = ["id", "set", "category", "source", "expect", "expect_entity", "判定",
              "action", "blocked", "検出", "latency_ms", "text_units", "text", "masked",
              "note", "error"]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    md_path = out_dir / f"summary_{stem}.md"
    md_path.write_text(summarize(rows, args.label), encoding="utf-8")

    print(f"\n件別結果: {csv_path}")
    print(f"サマリ  : {md_path}\n")
    print("\n".join(summarize(rows, args.label).split("\n")[:40]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
