# -*- coding: utf-8 -*-
"""3構成を作成 → 全290件を測定 → 比較表を出力、までを1コマンドで行う。

    export AWS_ACCESS_KEY_ID=...  AWS_SECRET_ACCESS_KEY=...
    export GUARDRAIL_REGION=us-east-1
    python3 verify_guardrail/run_all.py

    python3 verify_guardrail/run_all.py --keep     # 検証後にガードレールを残す
    python3 verify_guardrail/run_all.py --data data/min.jsonl   # 少量で試す
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY = sys.executable

CONFIGS = [
    ("01_classic",  "config/guardrail_01_standard.json", "①CLASSIC対照群"),
    ("02_strict",   "config/guardrail_02_strict.json",   "②STANDARD強化(HIGH)"),
    ("03_tuned",    "config/guardrail_03_tuned.json",    "③STANDARD業務調整"),
]


def sh(args: list[str], env: dict | None = None) -> tuple[int, str]:
    proc = subprocess.run(args, cwd=HERE, capture_output=True, text=True,
                          env={**os.environ, **(env or {})})
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def create(config: str) -> str:
    """ガードレールを作成して ID を返す。作成直後は Ready まで少し待つ。"""
    code, out = sh([PY, "setup_guardrail.py", "create", config])
    print(out.strip())
    if code != 0:
        return ""
    for line in out.splitlines():
        if "guardrailId" in line:
            return line.split(":")[-1].strip()
    for line in out.splitlines():
        if line.strip().startswith("export GUARDRAIL_ID="):
            return line.split("=", 1)[1].strip()
    return ""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--keep", action="store_true", help="検証後にガードレールを削除しない")
    parser.add_argument("--data", action="append", help="測定するJSONL（既定は全290件）")
    parser.add_argument("--source", default="BOTH", choices=["INPUT", "OUTPUT", "BOTH"])
    args = parser.parse_args()

    code, out = sh([PY, "setup_guardrail.py", "check"])
    print(out.strip())
    if code != 0:
        print("\n疎通に失敗しました。AWS認証情報を設定してから再実行してください。", file=sys.stderr)
        return 2

    created: list[tuple[str, str, str]] = []
    for label, config, title in CONFIGS:
        print(f"\n{'═'*72}\n{title}  ({config})\n{'═'*72}")
        gid = create(config)
        if not gid:
            print(f"  作成に失敗したため {label} は飛ばします。")
            continue
        created.append((label, gid, title))
        time.sleep(5)                       # Ready になるまでの猶予

        cmd = [PY, "probe.py", "--label", label, "--source", args.source]
        for name in (args.data or []):
            cmd += ["--data", name]
        code, out = sh(cmd, env={"GUARDRAIL_ID": gid})
        print(out.strip()[-2500:])

    # ── 比較表 ────────────────────────────────────────────
    print(f"\n{'═'*72}\n3構成の比較\n{'═'*72}")
    rows = []
    for label, gid, title in created:
        path = HERE / "result" / f"summary_{label}.md"
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        def pick(marker: str) -> str:
            for line in text.splitlines():
                if marker in line:
                    return line.strip()
            return "-"
        rows.append((title, gid,
                     pick("合計 "), pick("合格ライン 2%"), pick("1回あたり遅延")))
    for title, gid, det, fp, lat in rows:
        print(f"\n■ {title}  ({gid})")
        print(f"   検出率  : {det}")
        print(f"   誤検出  : {fp}")
        print(f"   遅延    : {lat}")

    print(f"\n件別CSVとサマリ: {HERE/'result'}")

    if not args.keep and created:
        print("\n検証用ガードレールを削除します（残す場合は --keep）")
        for label, gid, _ in created:
            code, out = sh([PY, "setup_guardrail.py", "delete", gid])
            print("  " + out.strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
