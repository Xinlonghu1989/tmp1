# ガードレール検証一式

HHグループ AI経営診断アプリ ／ STAGE 1 タスク② の検証資材です。
**まず [`ガードレール検証レポート.html`](./ガードレール検証レポート.html) をご覧ください**（実行の前提・必要なデータ・
操作手順・先行検証の結果をまとめています）。本ファイルは実行手順の抜粋です。

---

## 0. 3分で全体像

| | |
|---|---|
| 目的 | Bedrock Guardrails が**日本語の業務文でどこまで機能するか**を実測する |
| 推奨構成 | **`config/guardrail_06_tokyo_classic.json`** ＋ `self_guard.py`<br>検出率94% / 実害誤検出0.5% / **データは東京から出ない** |
| 最短ルート | §2の6ステップ、**半日** |
| 費用 | 最小セットなら数十円、全件×5構成でも**数ドル** |
| アプリへの影響 | **なし**。アプリのファイルは1バイトも変更しません |

---

## 1. 実行の前提

### 1-1. AWS認証情報【必須】

> **アプリが使っている `ANTHROPIC_API_KEY` とは別系統です。**
> 現行アプリは Anthropic互換エンドポイント（`bedrock-mantle.ap-northeast-1.api.aws/anthropic`）を
> 使っており、`ApplyGuardrail` が必要とする **IAM（SigV4）認証情報を持っていません**。

| 項目 | 内容 |
|---|---|
| 認証情報 | IAMロール（推奨）または アクセスキー。**ルートユーザーのキーは使わないでください** |
| 権限 | `config/iam_policy.json` をそのまま適用できます |
| リージョン | 本番想定 `ap-northeast-1`。先行検証は `us-east-1` で実施 |
| 依存 | `pip install -r requirements-verify.txt`（boto3 のみ） |

```bash
export AWS_ACCESS_KEY_ID='...'
export AWS_SECRET_ACCESS_KEY='...'
export GUARDRAIL_REGION='ap-northeast-1'
```

`~/.aws/credentials` に置く方法でも構いません（boto3 が自動で読みます）。

### 1-2. ティアは CLASSIC（東京完結）

**前提：データを東京リージョンから出さない。**

STANDARD ティアは**クロスリージョン推論**を要求し、東京のプロファイル
`apac.guardrail.v1:0` は東京・大阪・ソウル・シンガポール・シドニー・ムンバイの6リージョンを対象にします。
**東京だけに限定する選択肢はありません**（プロファイルは1つのみ）。

したがって **CLASSIC ティア**を使います。CLASSIC は日本語の有害表現・拒否トピックを検出できませんが、
**個人情報（氏名・住所・電話・メール・口座・社員番号・旅券）は日本語でも100%検出**します。
検出できない領域は `self_guard.py`（自前検査3層）で補い、**合計94%**に到達します。

| | Guardrails 単体 | ＋自前検査3層 |
|---|---:|---:|
| 検出率 | 55% | **94%** |
| 実害誤検出 | 0.5% | **0.5%** |
| 遅延 | p95 338ms | 約1.3秒 |

## 2. 最短ルート（半日）

```bash
# ① 疎通と権限の確認
pip install -r requirements-verify.txt
export AWS_ACCESS_KEY_ID='...'  AWS_SECRET_ACCESS_KEY='...'
export GUARDRAIL_REGION='ap-northeast-1'
python3 setup_guardrail.py check

# ② 設定の妥当性確認（AWS不要）
python3 validate_config.py

# ③ 推奨構成の作成
python3 setup_guardrail.py create config/guardrail_06_tokyo_classic.json
export GUARDRAIL_ID=<出力されたID>

# ④ 最小10件で疎通確認
python3 probe_min.py

# ⑤ 全280件を測定
python3 probe.py --label 本番相当 --source BOTH

# ⑥ 自前検査3層を合算した到達点を測定
python3 run_self_guard_eval.py
```

結果は `result/probe_<ラベル>.csv`（件別）と `summary_<ラベル>.md`（集計）に出ます。

### AWS認証情報が届く前にできること

```bash
python3 validate_config.py    # 設定がAPI仕様に適合するか（boto3同梱の定義と突合）
python3 selftest.py           # アプリへの差し替え機構（9項目）
python3 local_detector.py     # 正規表現だけのベースライン測定
python3 probe.py --dry-run    # 集計・CSV出力の配管確認
```

---

## 3. 全件測定（任意）

```bash
python3 run_all.py            # 5構成の作成 → 各280件×2方向 → 比較表 → 削除
python3 run_all.py --keep     # ガードレールを残す
```

構成あたり約7分、5構成で約35分です。

---

## 4. アプリとの結合確認（推奨）

**アプリのファイルは変更しません。** Python のモジュール属性を実行時に差し替えるだけで、
差し替えはそのプロセスのメモリ上にのみ存在します。

| 差し替える関数 | 検査する内容 |
|---|---|
| `ai_client.chat` | 利用者の発話（入口）と回答（出口）。全AI機能がここを通る |
| `ai_client.chat_json` | 同上。**値だけマスクし構造は保持**（株主総会Q&Aの13か所がJSON前提） |
| `response_store.record` | `question`（利用者入力）。`answer` は出口で検査済みだが `question` は素通りするため |
| `applog.event` | ログ本文。本文を書くのは1か所80文字のみのため、ローカル正規表現で処理 |

```bash
python3 selftest.py                                  # AWSなし・9項目
GUARDRAIL_ID=<ID> python3 phase2_test.py             # 実ガードレールと結合・11項目
GUARDRAIL_ID=<ID> python3 run_app_guarded.py         # 検査つきでアプリ起動（別ポート7899）
```

`run_app_guarded.py` は `PUBLIC_DATA_DIR` を検証用ディレクトリに向けるため、
**本番の `runtime_data/` には一切書き込みません**。

> **初回起動に時間がかかります。**
> データ隔離の副作用で RAG索引がゼロから構築されます。
> 先行検証では最初の質問が325秒経っても返りませんでしたが、原因はガードレールではなく索引構築でした。
> 「社内資料検索」をオフにすれば即座に回答が返ります。

---

## 5. 同梱物と配置

### アプリ本体は無改造です

本検証で `app.py` / `ai_client.py` / `response_store.py` / `applog.py` / `ui.py` /
`knowledge_rag.py` / `ai_prompts.py` / `agm/*` のいずれも編集していません。
検証資材は**このフォルダ1つ**にまとまっており、**フォルダごと削除すれば元の状態に戻ります**。

```
gradio_app_0825/                        ← アプリ本体（無改造）
├── app.py, ai_client.py, ui.py …       変更なし
│
└── ガードレール検証_20260830/            ← 今回追加。ここだけで完結
    ├── ガードレール検証レポート.html
    ├── README.md
    ├── requirements-verify.txt
    ├── config/     ガードレール定義＋IAMポリシー
    ├── data/       テストケース 290件
    ├── result/     測定結果（CSV・サマリ）
    └── *.py        実行スクリプト
```

**依存は一方向です。** 検証スクリプトの一部（`wrap.py` / `selftest.py` / `phase2_test.py` /
`self_guard.py`）はアプリのモジュールを import しますが、
**アプリ側は検証コードを一切参照していません**（参照ゼロ件）。
本番稼働には影響せず、削除してもアプリは動きます。

### 再現に必要なもの

**本フォルダを、アプリのフォルダ（`gradio_app_0825/`）の直下に置いてください。**
Guardrails 単体の測定はフォルダだけで完結しますが、自前検査のLLM分類層とアプリ結合の確認は
アプリのモジュールを参照するため、切り離すと動きません（実測で確認済み）。

| 再現できる範囲 | 必要なもの | 該当スクリプト |
|---|---|---|
| Guardrails の構築・全280件の測定・誤検出の集計 | **本フォルダ＋AWS認証情報**<br>（アプリ不要） | `setup_guardrail.py` `validate_config.py` `probe_min.py` `probe.py` `run_all.py` `local_detector.py` |
| 自前検査のうち**LLM分類層**（有害表現） | ＋アプリ本体 | `self_guard.py` `run_self_guard_eval.py` |
| アプリとの結合確認・実画面での動作 | ＋アプリ本体 | `wrap.py` `selftest.py` `phase2_test.py` `run_app_guarded.py` |
| テストデータの再生成（**不要**。生成済みを同梱） | ＋`data_external/` | `build_d_from_ir.py` |

辞書層・正規表現層（拒否トピック・プロンプト注入）はアプリに依存しません。

### STEP 2 での移行先

| 検証時（外付け） | STEP 2（アプリ本体） |
|---|---|
| `wrap.py` の入口・出口検査 | `ai_client.py` の `chat()` / `chat_json()` に組み込む |
| `wrap.py` の `record` 差し替え | `response_store.record()` の保存前に検査を追加 |
| `wrap.py` のログマスク | `applog.py` の `_scrub()` にPIIマスクを追加 |
| `self_guard.py`（3層） | 新規モジュールとして追加し `ai_client` から呼ぶ |
| 外部テキストの隔離 | `ai_prompts.py` のプロンプト組み立て1か所 |
| （未実装）Word出力の検査 | `export_docx.build()` の生成前に同じ検査を通す |

### スクリプトの役割

| ファイル | 役割 | AWS |
|---|---|---|
| `setup_guardrail.py` | 疎通確認・ガードレールの作成／一覧／削除／プロファイル確認 | 要 |
| `probe_min.py` | 最小10件で方針を判定 | 要 |
| `probe.py` | 測定本体。CSVとサマリを出力（`--dry-run` でAWS不要） | 要 |
| `run_all.py` | 全構成を一括実行して比較表を出力 | 要 |
| `phase2_test.py` | ラッパー＋実ガードレールの結合確認（11項目） | 要 |
| `run_app_guarded.py` | 検査つきでアプリを起動 | 要 |
| `validate_config.py` | 設定をAPI定義と突合 | 不要 |
| `selftest.py` | 差し替え機構の検証（9項目） | 不要 |
| `local_detector.py` | 正規表現だけのベースライン測定 | 不要 |
| **`self_guard.py`** | **自前検査3層の試作**（辞書／正規表現／LLM分類） | 要 |
| `run_self_guard_eval.py` | 自前検査とGuardrailsを合算して集計 | 要 |
| `guard.py` / `wrap.py` | ApplyGuardrail の薄い層 ／ 4関数の差し替え | — |
| `build_d_from_ir.py` | 公開IR資料から誤検出テスト用の実文を生成 | 不要 |

---

## 6. データの取り扱い

- **実データは1件も含みません。**すべて合成・架空です
  （教科書的な例示電話番号、予約ドメイン `example.com`、存在しない番地、業界標準のテストカード番号）
- 有害表現は**分類器が反応する程度の定型句**にとどめ、実際に有害な文章は作っていません
- `data/d_normal_ir.jsonl` の素材は**公表済みの開示資料のみ**。非公開の社内資料は参照していません
- **ダミーデータを `data_internal/` に置かないでください**（RAG索引に取り込まれ、本末転倒になります）
- 検証終了後は生成物と検証用ガードレールを削除してください

```bash
python3 setup_guardrail.py list
python3 setup_guardrail.py delete <guardrailId>
```

---

## 7. 先行検証で判明した「設定の罠」

### ① `inputEnabled` / `outputEnabled` を書かないと評価が一切行われない

先行検証の最初の実行は**検出率 0/8** でした。`action` は書いてあるのに何も検出されません。
API定義に「無効時は課金されず、**レスポンスにも現れない**」と明記されています。
**コンソールのGUIは自動で立てるため、画面上は正常に見えます。**
設定ファイルやIaCで構築する場合、**設定は正しく見えるのに全く効いていない**状態が作れます。

```json
// 効かない
{"type": "NAME", "action": "ANONYMIZE"}

// 効く
{"type": "NAME", "action": "ANONYMIZE", "inputEnabled": true, "outputEnabled": true}
```

同梱の `config/*.json` は修正済みです。**導入後は必ず既知のPIIを1件通して検出を確認してください。**

### ② 正規表現の先読み・後読みが使えない

`(?=)` `(?!)` `(?<=)` `(?<!)` はすべて `Regex pattern is invalid.` になります。
境界指定ができないため `[0-9]{12}` がタイムスタンプにも一致します。
桁の境界判定と検査用数字の検証は、自前検査（STEP 2）で行ってください。

### ③ 拒否トピックの名前は ASCII のみ

`[0-9a-zA-Z-_ !?.]+` のみ。日本語は `ValidationException` になります。
定義文と例文は日本語で問題ありません。

---

## 8. 先行検証の結果（要約）

**規模**：280件 × 入力側・出力側の2方向（検出すべき96件／止めてはいけない184件）、
リージョン `ap-northeast-1`、ティア CLASSIC、クロスリージョン推論なし。

| 層 | 検出率 | 実害誤検出 |
|---|---:|---:|
| Guardrails のみ | 53/96（55%） | 1/184（0.5%） |
| ＋ 辞書・正規表現 | 68/96（71%） | 1/184（0.5%） |
| **＋ LLM分類【推奨】** | **90/96（94%）** | **1/184（0.5%）** |

- **個人情報は Guardrails だけで 51/54**。CLASSIC・東京完結でも、APAC転送を許容した場合と1件の差もありません
- **自前で作るのは有害表現・注入・拒否トピックの3領域のみ**。試作 `self_guard.py` は約100行
- **自前層が追加した誤検出は 0/184**。LLM分類に「統計・防止策・規程の検討は該当しない」と明示したことで、
  「駅構内での暴力行為の件数と、鉄道係員への安全対策を確認したい」のような業務文が正しく素通りします

### 設定上の注意（Guardrails 側）

- **ADDRESS は検出のみに設定**。マスクすると「西宮北口駅の乗降人員」が「{ADDRESS}の乗降人員」になり業務が成立しません
- **拒否トピックは Guardrails では使わない**。CLASSIC では日本語の未公表案件を0/13しか検出せず、
  逆に「BX推進室」「路線コードHK-01」に誤爆したため。キーワード辞書で代替します

詳細は `ガードレール検証レポート.html` をご覧ください。
