# -*- coding: utf-8 -*-
"""自前実装（3層）を全280件に適用し、構成⑥と合算した到達点を測る。

LLM判定は1件あたり2〜3秒かかるため、控えめな並列で回す。
"""
from __future__ import annotations
import csv, sys, time, collections
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0, ".")
import self_guard as sg

rows = [r for r in csv.DictReader(open("result/probe_06_tokyo_classic.csv", encoding="utf-8-sig"))
        if r["source"] == "INPUT"]
print(f"対象 {len(rows)}件（LLM判定を含むため数分かかります）")

t0 = time.monotonic()
def judge(r):
    rule = [h for h in (sg.check_denied_topic(r["text"]), sg.check_injection(r["text"])) if h]
    llm = sg.check_harmful_llm(r["text"])
    return r, rule, llm

done = 0
out = []
with ThreadPoolExecutor(max_workers=6) as ex:
    for r, rule, llm in ex.map(judge, rows):
        out.append((r, rule, llm)); done += 1
        if done % 40 == 0:
            print(f"  {done}/{len(rows)} … {time.monotonic()-t0:.0f}秒")

with open("result/self_guard_eval.csv", "w", encoding="utf-8-sig", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["id","set","category","expect","guardrail判定","ルール層","LLM層","text"])
    for r, rule, llm in out:
        w.writerow([r["id"], r["set"], r["category"], r["expect"], r["判定"],
                    ";".join(rule), llm, r["text"]])

# ── 集計 ─────────────────────────────────────────────
cat = collections.defaultdict(lambda: [0,0,0,0])   # ⑥, +ルール, +LLM, 件数
for r, rule, llm in out:
    if r["expect"] == "PASS": continue
    k = f'{r["set"]}／{r["category"]}'
    cat[k][3] += 1
    g = r["判定"] == "正解"
    if g: cat[k][0] += 1
    if g or rule: cat[k][1] += 1
    if g or rule or llm: cat[k][2] += 1

print(f"\n{'カテゴリ':<24}{'⑥のみ':>7}{'+ルール':>9}{'+LLM':>7}{'件数':>7}")
print("─" * 62)
tot = [0,0,0,0]
for k in sorted(cat):
    a,b,c,t = cat[k]
    for i,v in enumerate((a,b,c,t)): tot[i] += v
    print(f"{k:<24}{a:>7}{b:>9}{c:>7}{t:>7}")
print("─" * 62)
print(f"{'合計':<24}{tot[0]:>7}{tot[1]:>9}{tot[2]:>7}{tot[3]:>7}")
print(f"{'検出率':<24}{tot[0]/tot[3]*100:>6.0f}%{tot[1]/tot[3]*100:>8.0f}%{tot[2]/tot[3]*100:>6.0f}%")

neg = [(r,rule,llm) for r,rule,llm in out if r["expect"] == "PASS"]
def harmed(r): return r["blocked"]=="True" or (r["masked"] and r["masked"][:150]!=r["text"][:150])
fp_g = [x for x in neg if x[0]["判定"]=="誤検出" and harmed(x[0])]
fp_s = [x for x in neg if x[1] or x[2]]
fp_all = {x[0]["id"] for x in fp_g} | {x[0]["id"] for x in fp_s}
print(f"\n誤検出（実害ベース）")
print(f"  ⑥ガードレールのみ      : {len(fp_g)}/{len(neg)} = {len(fp_g)/len(neg)*100:.1f}%")
print(f"  自前層が追加した誤検出  : {len(fp_s)}/{len(neg)} = {len(fp_s)/len(neg)*100:.1f}%")
print(f"  合算                   : {len(fp_all)}/{len(neg)} = {len(fp_all)/len(neg)*100:.1f}%")
if fp_s:
    print("\n  自前層の誤検出内訳:")
    for r,rule,llm in fp_s[:15]:
        print(f"   {r['id']:<11}{(';'.join(rule)+' '+llm).strip()[:30]:<32}{r['text'][:44]}")
print(f"\n所要 {time.monotonic()-t0:.0f}秒")
