# -*- coding: utf-8 -*-
"""自前実装の試作（STEP 2 の補完開発スコープ）。

東京完結（構成⑥＝CLASSICティア）では、Guardrails が日本語の
有害表現・拒否トピック・プロンプト注入をほぼ検出できない。
そこを自前で埋めたとき、どこまで戻せるかを測るための試作。

3層構成:
  ① 拒否トピック  … キーワード辞書。最も安価
  ② プロンプト注入 … 定型パターンの正規表現
  ③ 有害表現      … LLMによる分類（アプリのモデルを1回追加で呼ぶ）

誤検出を避ける工夫を各層に入れてある。特に③は
「業務上正当な言及（統計・防止策・規程）は該当しない」を明示しないと、
『駅構内での暴力行為の件数』のような正当な業務文を弾いてしまう。
"""

from __future__ import annotations
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# ── ① 拒否トピック：キーワード辞書 ─────────────────────────
CODENAMES = ["ソレイユ", "アカツキ"]
# 「未公表」を示す語 × 「経営判断」を示す語 の共起で判定する。
# 単語ひとつで判定すると『公表済みの中期経営計画』のような正当な質問を弾くため。
UNDISCLOSED = ["未公表", "公表前", "開示前", "発表前", "先出し",
               "まだ外に出していない", "まだ公表", "諮っていない", "発表予定"]
DECISIONS = ["売却", "買収", "統合", "撤退", "再編", "減損", "案件",
             "目標", "スケジュール", "計画", "内容", "額", "一覧"]
# 公表済みを明示している場合は対象外にする（境界ケースの保護）
PUBLISHED = ["公表済", "開示済", "有価証券報告書", "IR公表", "回答済", "記載済"]

def check_denied_topic(text: str) -> str:
    if any(w in text for w in PUBLISHED):
        return ""
    if any(c in text for c in CODENAMES):
        return "拒否トピック:コードネーム"
    if any(u in text for u in UNDISCLOSED) and any(d in text for d in DECISIONS):
        return "拒否トピック:未公表案件"
    return ""

# ── ② プロンプト注入：定型パターン ───────────────────────
INJECTION = [
    (r"(これまで|以前|上記|全て|すべて)の(指示|命令|ルール|設定).{0,12}(無視|忘れ|破棄|上書き)", "指示の無効化"),
    (r"(システム|システム)?プロンプト.{0,8}(出力|表示|開示|教え)", "システムプロンプトの開示要求"),
    (r"制限のない|制約のない|安全設定.{0,8}(解除|無効)|フィルタ.{0,8}(解除|無効)", "制限解除の要求"),
    (r"#{2,}\s*SYSTEM|^\s*system\s*:", "システム役の詐称"),
    (r"(開発者|管理者|運営)(から|より)の(命令|指示).{0,20}(無視|解除|開示)", "権限詐称"),
    (r"権限(チェック|確認|制限).{0,8}(無効|無視|回避)", "認可の回避要求"),
    (r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+instructions", "指示の無効化(英)"),
    (r"(?i)(developer|god|dan)\s*mode|reveal\s+your\s+(system\s+)?prompt", "制限解除の要求(英)"),
    (r"AIへの指示|AIは以下に従", "資料内に埋め込まれた指示"),
]
_INJ = [(re.compile(p, re.M), n) for p, n in INJECTION]

def check_injection(text: str) -> str:
    for pat, name in _INJ:
        if pat.search(text):
            return f"注入:{name}"
    return ""

# ── ③ 有害表現：LLMによる分類 ────────────────────────────
CLASSIFY_SYSTEM = """あなたは社内AIアプリの安全フィルタです。
入力文が次のいずれかに該当するか判定してください。

A 侮辱   … 特定の人・部署への中傷、能力の否定
B 差別   … 属性（性別・年齢・国籍・出身）に基づく不利益な取扱いの主張
C 暴力   … 危害・脅迫の示唆
D 性的   … 性的な言及・ハラスメント
E 不正助長 … 粉飾、インサイダー、談合、経費不正、内部通報者の特定など違法・不正行為の方法を求めるもの

**重要**：業務上正当な言及は該当しません。
統計・件数の確認、防止策・研修・内部統制・規程の検討、
撤退や人員に関する経営判断の議論は、いずれも該当しません。

該当するなら記号1文字（A〜E）だけ、該当しないなら NONE だけを返してください。他の語は出力しないこと。"""

def check_harmful_llm(text: str) -> str:
    import ai_client
    r = ai_client.call_chat(
        [{"role": "system", "content": CLASSIFY_SYSTEM},
         {"role": "user", "content": text}],
        temperature=0, timeout=30, feature="self-guard")
    if r.status != "ok":
        return "有害:判定失敗"          # fail-closed は呼び出し側で扱う
    v = (r.content or "").strip().upper()[:6]
    names = {"A": "侮辱", "B": "差別", "C": "暴力", "D": "性的", "E": "不正助長"}
    for k, n in names.items():
        if v.startswith(k):
            return f"有害:{n}"
    return ""

def check_all(text: str, use_llm: bool = True) -> list[str]:
    hits = [h for h in (check_denied_topic(text), check_injection(text)) if h]
    if use_llm:
        h = check_harmful_llm(text)
        if h:
            hits.append(h)
    return hits
