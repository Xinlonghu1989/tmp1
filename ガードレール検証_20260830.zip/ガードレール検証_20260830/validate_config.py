# -*- coding: utf-8 -*-
"""AWS認証情報なしで、config/*.json が API 仕様に適合するかを検証する。

boto3 に同梱されている **API 定義そのもの**（botocore のサービスモデル）と
突き合わせるため、ネットワークにも認証情報にも一切依存しない。
「作成してみたら ValidationException だった」を事前に潰すのが目的。

検証する内容:
  ① CreateGuardrail に無いキーを使っていないか（階層を再帰的に確認）
  ② 必須キーが欠けていないか
  ③ 列挙値（PIIの種別・フィルタ強度・ティア名など）が正しいか
  ④ 型が合っているか
  ⑤ カスタム正規表現が Python で構文として通るか
  ⑥ 日本語を扱ううえでの設定上の注意（CLASSICティア等）

    python3 validate_config.py
    python3 validate_config.py config/guardrail_02_strict.json
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

TYPE_MAP = {
    "string": str, "integer": int, "long": int, "float": float, "double": float,
    "boolean": bool, "structure": dict, "list": list, "map": dict,
}


def model():
    import botocore.session
    session = botocore.session.get_session()
    return session.get_service_model("bedrock").operation_model("CreateGuardrail").input_shape


def walk(value, shape, path: str, errors: list[str], warns: list[str]) -> None:
    expected = TYPE_MAP.get(shape.type_name)
    if expected and not isinstance(value, expected):
        # int を期待する所に float が来るのは許す
        if not (expected is float and isinstance(value, (int, float))):
            errors.append(f"{path}: 型が {shape.type_name} であるべきですが "
                          f"{type(value).__name__} です")
            return
    if shape.type_name == "structure":
        known = set(shape.members)
        for key in value:
            if key.startswith("_"):        # 自前のコメント欄は無視する
                continue
            if key not in known:
                near = ", ".join(sorted(known)[:6])
                errors.append(f"{path}.{key}: API に存在しないキーです（候補: {near} …）")
        for key in (shape.required_members or []):
            if key not in value:
                errors.append(f"{path}.{key}: 必須キーが欠けています")
        for key, item in value.items():
            if key.startswith("_") or key not in known:
                continue
            walk(item, shape.members[key], f"{path}.{key}", errors, warns)
    elif shape.type_name == "list":
        for index, item in enumerate(value):
            walk(item, shape.member, f"{path}[{index}]", errors, warns)
    elif shape.type_name == "string":
        allowed = getattr(shape, "enum", None)
        if allowed and value not in allowed:
            errors.append(f"{path}: '{value}' は許可されていません。"
                          f"許可値: {', '.join(allowed)}")
        meta = shape.metadata or {}
        if "max" in meta and isinstance(value, str) and len(value) > meta["max"]:
            errors.append(f"{path}: {len(value)}文字は上限 {meta['max']} を超えます")
        if "min" in meta and isinstance(value, str) and len(value) < meta["min"]:
            errors.append(f"{path}: {len(value)}文字は下限 {meta['min']} を下回ります")


def extra_checks(config: dict, name: str, warns: list[str], notes: list[str]) -> None:
    content = config.get("contentPolicyConfig") or {}
    tier = ((content.get("tierConfig") or {}).get("tierName")) or "CLASSIC（既定）"
    notes.append(f"コンテンツフィルタのティア: {tier}")
    if str(tier).startswith("CLASSIC"):
        warns.append("CLASSIC ティアは英語・フランス語・スペイン語のみ対応です"
                     "（API定義に明記）。日本語を扱うなら STANDARD が必要です。")
    if str(tier) == "STANDARD" and "crossRegionConfig" not in config:
        warns.append("STANDARD ティアはクロスリージョン推論を要求します。"
                     "crossRegionConfig を指定してください。")
    profile = (config.get("crossRegionConfig") or {}).get("guardrailProfileIdentifier")
    if profile and str(profile).startswith("REPLACE_ME"):
        warns.append("crossRegionConfig.guardrailProfileIdentifier が REPLACE_ME のままです。"
                     "`setup_guardrail.py profiles` で確認して差し替えてください。")

    sensitive = config.get("sensitiveInformationPolicyConfig") or {}
    for index, item in enumerate(sensitive.get("regexesConfig") or []):
        pattern = item.get("pattern", "")
        try:
            re.compile(pattern)
        except re.error as exc:
            warns.append(f"regexesConfig[{index}]（{item.get('name')}）: "
                         f"Python では構文エラーになります（{exc}）。"
                         "AWS側の正規表現エンジンとは方言が異なる可能性があります。")
    pii = [i.get("type") for i in sensitive.get("piiEntitiesConfig") or []]
    if pii:
        notes.append(f"マネージドPII: {len(pii)}種別を指定")
    jp_needed = {"マイナンバー", "社員番号", "銀行口座"}
    have = {i.get("name") for i in sensitive.get("regexesConfig") or []}
    missing = jp_needed - have
    if missing:
        warns.append(f"日本固有のIDに対応する正規表現がありません: {', '.join(sorted(missing))}。"
                     "マネージドPIIには日本の種別が存在しないため、正規表現でしか拾えません。")


def check(path: Path) -> bool:
    print(f"\n── {path.name} " + "─" * max(0, 60 - len(path.name)))
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"  ✗ JSON として読めません: {exc}")
        return False
    errors: list[str] = []
    warns: list[str] = []
    notes: list[str] = []
    walk({k: v for k, v in config.items() if not k.startswith("_")},
         model(), "", errors, warns)
    extra_checks(config, path.name, warns, notes)

    for note in notes:
        print(f"  ・{note}")
    for warn in warns:
        print(f"  △ {warn}")
    for err in errors:
        print(f"  ✗ {err}")
    if not errors:
        print("  ✓ CreateGuardrail の仕様に適合しています"
              + ("（要対応の注意あり）" if warns else ""))
    return not errors


def main() -> int:
    try:
        import botocore  # noqa: F401
    except ImportError:
        print("botocore が必要です: pip install boto3", file=sys.stderr)
        return 2
    import botocore.session
    version = botocore.session.get_session().get_service_model("bedrock").api_version
    print(f"検証に使う API 定義: bedrock {version}（boto3 同梱。ネットワーク不要）")

    # config/ にはIAMポリシーも同居するため、ガードレール定義だけを対象にする
    targets = ([Path(a) for a in sys.argv[1:]]
               or sorted(p for p in (HERE / "config").glob("guardrail_*.json")))
    ok = all(check(p) for p in targets)
    print("\n" + ("すべて適合しています。" if ok else "適合しない項目があります。上記を修正してください。"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
