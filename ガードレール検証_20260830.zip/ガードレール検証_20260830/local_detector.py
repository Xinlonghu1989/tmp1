# -*- coding: utf-8 -*-
"""AWSを使わない自前検出器。config の正規表現をそのまま適用する。

2つの役割がある。

  ① ベースラインの測定
     「正規表現だけでどこまで拾えるか」を先に確定させる。Guardrails を
     動かしたとき、その数字との差分が **Guardrails が上乗せした価値** になる。
     日本語のマネージドPIIは存在しない（API定義で確認済み）ため、
     日本固有のIDはここで測った値がほぼ実力値になる。

  ② probe.py の --dry-run の実体
     AWS認証情報が届く前に、集計・CSV出力・サマリ生成まで一通り動かして
     配管を確認する。

    python3 local_detector.py                       # 全セットでベースライン測定
    python3 local_detector.py --config config/guardrail_03_tuned.json
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import guard  # noqa: E402

# マネージドPIIの代替として最低限持つパターン。
# NAME と ADDRESS は正規表現では原理的に拾えない（辞書・文脈解析が要る）。
# 「正規表現で届く範囲／届かない範囲」を分けて見せることが目的。
# 日本語文中では \b と \w が使えない。
#   Python の \w は Unicode の語構成文字を含むため、「連絡先は090-…」のように
#   前後が日本語だと (?<!\w) が常に成立せず、一切マッチしなくなる（実測で確認）。
#   そこで境界は ASCII の英数字とハイフンだけで表現する。
_L = r"(?<![0-9０-９A-Za-zＡ-Ｚａ-ｚ\-－])"
_R = r"(?![0-9０-９A-Za-zＡ-Ｚａ-ｚ\-－])"

BUILTIN = [
    ("EMAIL", r"[\w.+-]+@[\w-]+\.[\w.-]+"),
    ("CREDIT_DEBIT_CARD_NUMBER", _L + r"(?:[0-9][ -]?){13,18}[0-9]" + _R),
    ("PHONE", _L + r"0[0-9０-９]{1,4}[-－\s]?[0-9０-９]{1,4}[-－\s]?[0-9０-９]{3,4}" + _R),
    ("URL", r"https?://[^\s]+"),
]
UNREACHABLE = ("NAME", "ADDRESS")   # 正規表現では届かない種別


def load_patterns(config_path: Path) -> list[tuple[str, re.Pattern]]:
    """config のカスタム正規表現＋組み込みパターンを、具体的な順に並べて返す。"""
    patterns: list[tuple[str, re.Pattern]] = []
    config = json.loads(config_path.read_text(encoding="utf-8"))
    for item in ((config.get("sensitiveInformationPolicyConfig") or {})
                 .get("regexesConfig") or []):
        try:
            patterns.append((item["name"], re.compile(item["pattern"])))
        except re.error as exc:
            print(f"（無効な正規表現）{item.get('name')}: {exc}", file=sys.stderr)
    for name, pattern in BUILTIN:
        patterns.append((name, re.compile(pattern)))
    return patterns


def detect(text: str, patterns) -> list[guard.Detection]:
    found = []
    remaining = text
    for name, pattern in patterns:       # 具体的なものから順に潰す
        if pattern.search(remaining):
            found.append(guard.Detection("regex", name, "ANONYMIZED"))
            remaining = pattern.sub("{MASK}", remaining)
    return found


def make_check(patterns):
    """guard.check と同じ形の関数を返す（probe.py から差し替えて使う）。"""
    def local_check(text, source="INPUT", **kwargs):
        found = detect(text or "", patterns)
        masked = text or ""
        for name, pattern in patterns:
            masked = pattern.sub(f"{{{name}}}", masked)
        return guard.GuardResult(
            ok=True,
            action="GUARDRAIL_INTERVENED" if found else "NONE",
            blocked=False, text=masked, detections=found,
            latency_ms=0, text_units=guard.text_units(text or ""),
        )
    return local_check


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/guardrail_02_strict.json")
    parser.add_argument("--data", action="append")
    args = parser.parse_args()

    patterns = load_patterns(HERE / args.config if not Path(args.config).is_absolute()
                             else Path(args.config))
    print(f"適用する正規表現 {len(patterns)}件: "
          f"{', '.join(n for n, _ in patterns)}\n")

    files = args.data or ["data/a_pii.jsonl", "data/b_harmful.jsonl",
                          "data/c_secret.jsonl", "data/d_normal.jsonl",
                          "data/d_normal_ir.jsonl"]
    records = []
    for name in files:
        path = HERE / name
        if path.exists():
            records += [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]

    by_cat: dict[str, list[bool]] = {}
    fp_rows = []
    for record in records:
        hit = bool(detect(record["text"], patterns))
        key = f'{record["set"]}／{record["category"]}'
        by_cat.setdefault(key, []).append(hit)
        if record["expect"] == "PASS" and hit:
            fp_rows.append((record["id"], record["category"],
                            ";".join(d.kind for d in detect(record["text"], patterns)),
                            record["text"][:70]))

    print("■ 正規表現だけのベースライン（Guardrails未使用）\n")
    print(f"{'セット／カテゴリ':<34}{'件数':>5}{'検出':>6}{'率':>8}")
    print("─" * 56)
    positives = negatives = pos_hit = neg_hit = 0
    for key in sorted(by_cat):
        hits = by_cat[key]
        rate = sum(hits) / len(hits) * 100
        print(f"{key:<34}{len(hits):>5}{sum(hits):>6}{rate:>7.0f}%")
        if key.startswith("D") or "境界" in key:
            negatives += len(hits); neg_hit += sum(hits)
        else:
            positives += len(hits); pos_hit += sum(hits)

    print("─" * 56)
    if positives:
        print(f"検出されるべき行の検出率 : {pos_hit}/{positives} = {pos_hit/positives*100:.1f}%")
    if negatives:
        print(f"止めてはいけない行の誤検出: {neg_hit}/{negatives} = {neg_hit/negatives*100:.1f}%"
              f"（合格ライン 2%以下 → {'合格' if neg_hit/negatives*100 <= 2 else '未達'}）")

    print(f"\n■ 正規表現では原理的に届かない種別: {', '.join(UNREACHABLE)}")
    print("  日本語の氏名・住所は文脈と辞書が要るため、Guardrails のマネージドPII"
          "（NAME/ADDRESS）が日本語で機能するかどうかが分岐点になります。")

    if fp_rows:
        print(f"\n■ 誤検出の内訳（{len(fp_rows)}件）")
        for row in fp_rows[:25]:
            print(f"  {row[0]:<12}{row[1]:<16}{row[2]:<22}{row[3]}")
        if len(fp_rows) > 25:
            print(f"  … 他 {len(fp_rows)-25}件")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
